package umn.ac.id.week04b_00000033631;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private View btnHalaman1;
    private View btnHalaman2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnHalaman1=findViewById(R.id.main_button_change_1);
        btnHalaman2=findViewById(R.id.main_button_change_2);
        btnHalaman1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intenthalaman1=new Intent(MainActivity.this, SecondActivity.class);
                startActivity(intenthalaman1);
            }
        });
        btnHalaman2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intenthalaman2=new Intent(MainActivity.this, ThirdActivity.class);
                startActivity(intenthalaman2);
            }
        });
    }
}